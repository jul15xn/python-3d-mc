from lib import window

window.StartWindow()
window.WindowLoop()